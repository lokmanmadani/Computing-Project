@extends('layouts.app')

@section('content')
<a href="/events" class="btn btn-primary"> Back to Calendar </a>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Attendance list</div>


                <div class="card-body">

                    <a href="{{ route('atts.create') }}" class="btn btn-primary">Add new Attendance</a>
                    <br /><br />


                    <table class="table">
                        <tr>
                            <th>Student Name</th>
                            <th>Student ID</th>
                        </tr>
                        @forelse ($atts as $att)
                            <tr>
                                <td>{{ $att->title }}</td>
                                <td><a href="{{ route('atts.download', $att->uuid) }}">{{ $att->cover }}</a></td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="2">No Attendance found.</td>
                            </tr>
                        @endforelse
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
