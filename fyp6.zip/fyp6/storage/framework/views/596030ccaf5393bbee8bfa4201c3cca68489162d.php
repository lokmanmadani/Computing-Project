<!DOCTPYE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"
    <meta http-equiv="X-UA-Compatible" content="ie-edge">

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Document</title>


</head>
<body>

 <div class="container">
   <div class="jumbotron">

     <table class="table table-striped table-bordered table-hover">
       <thread class="thread">
         <tr class="warning">
           <th> Id </th>
           <th> Title </th>
            <th> Color </th>
           <th> START Date </th>
            <th> End Date </th>
            <th> Update / Edit </th>
            <th> Delete </th>
          </tr>
        </thread>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
          <tr>
              <td><?php echo e($event->id); ?></td>
              <td><?php echo e($event->title); ?></td>
              <td><?php echo e($event->color); ?></td>
              <td><?php echo e($event->start_date); ?></td>
              <td><?php echo e($event->end_date); ?></td>

              <th><a href="<?php echo e(action('EventController@edit',$event['id'])); ?>" class="btn btn-success">
                 Edit </a>
              </th>
                <th>
                  <form method="POST" action="<?php echo e(action('EventController@destroy',$event['id'])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE" />
                    <button type="submit" class="btn btn-danger">
                      <i class="glyphicon glyphicon-trash"></i> Delete </button>
                  </form>
                </th>

            </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

   </div>
 </div>
</body>
</html>
