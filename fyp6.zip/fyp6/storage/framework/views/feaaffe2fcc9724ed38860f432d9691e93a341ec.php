<?php $__env->startSection('content'); ?>
<a href="/events" class="btn btn-primary"> Back to Calendar </a>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Attendance list</div>


                <div class="card-body">

                    <a href="<?php echo e(route('atts.create')); ?>" class="btn btn-primary">Add new Attendance</a>
                    <br /><br />


                    <table class="table">
                        <tr>
                            <th>Student Name</th>
                            <th>Student ID</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $atts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($att->title); ?></td>
                                <td><a href="<?php echo e(route('atts.download', $att->uuid)); ?>"><?php echo e($att->cover); ?></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2">No Attendance found.</td>
                            </tr>
                        <?php endif; ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>