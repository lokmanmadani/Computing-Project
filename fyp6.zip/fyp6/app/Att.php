<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Att extends Model
{
     protected $fillable = ['uuid', 'title', 'cover'];
}
