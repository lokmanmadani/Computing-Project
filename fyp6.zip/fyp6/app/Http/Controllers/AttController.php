<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Att;
use Webpatser\Uuid\Uuid;

class AttController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $atts = Att::all();
      return view('atts.index', compact('atts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('atts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $att = $request->all();
  $att['uuid'] = (string)Uuid::generate();
  if ($request->hasFile('cover')) {
      $att['cover'] = $request->cover->getClientOriginalName();
      $request->cover->storeAs('atts', $att['cover']);
  }
  Att::create($att);
  return redirect()->route('atts.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function download($uuid)
    {
      $att = Att::where('uuid', $uuid)->firstOrFail();
    $pathToFile = storage_path('app/atts/' . $att->cover);
    return response()->download($pathToFile);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
